<template>
	<div>dailyProductionAmount</div>
</template>

<script>
</script>

<style>
</style>