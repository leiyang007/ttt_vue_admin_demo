<template>
	<div>salesDataManagement</div>
</template>

<script>
</script>

<style>
</style>