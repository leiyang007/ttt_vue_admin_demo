<template>
	<div>productStandard</div>
</template>

<script>
</script>

<style>
</style>