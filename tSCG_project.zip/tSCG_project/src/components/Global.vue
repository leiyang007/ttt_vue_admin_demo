
<script>
/*
 * 全局公用常量和方法
 * author by leiyang	2018.10.19
 * */
	
	let pageSize = 10

	  export default
	  {
	    pageSize,
	  }
</script>
