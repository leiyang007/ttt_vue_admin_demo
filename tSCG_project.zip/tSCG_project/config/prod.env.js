module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: '"http://13.229.230.131:8080"'
}
